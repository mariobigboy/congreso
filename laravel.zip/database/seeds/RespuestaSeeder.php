<?php

use Illuminate\Database\Seeder;
use App\Respuesta;

class RespuestaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	//respuesta 1:
        $respuesta = new Respuesta();
        $respuesta->comentario = 'esta es la primer respuesta al comentario 1';
        $respuesta->comentario_id = 1;
        $respuesta->likes = 0;
        $respuesta->user_id = 2; //user 2 es admin
        $respuesta->save();

        //respuesta 2 al mismo comentario:
        $respuesta = new Respuesta();
        $respuesta->comentario = 'esta es la segunda respuesta al comentario 1';
        $respuesta->comentario_id = 1;
        $respuesta->likes = 0;
        $respuesta->user_id = 3; //user 3 es user
        $respuesta->save();
    }
}
