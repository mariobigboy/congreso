<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card ">
                <div class="card-header">
                    <div class="row">
                        <div class="col-8">
                            <h4 class="card-title"><strong><?php echo e(__('Disertantes')); ?></strong></h4>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('disertantes.create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Nuevo Disertante')); ?></a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                          <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
                            <i class="tim-icons icon-simple-remove"></i>
                          </button>
                          <span>
                            <b> <?php echo e(session('status')); ?></span>
                        </div>
                    <?php endif; ?>

                    
                    <?php if(session('success_delete')): ?>
                        <div class="alert alert-success">
                          <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
                            <i class="tim-icons icon-simple-remove"></i>
                          </button>
                          <span>
                            <b> <?php echo e(session('success_delete')); ?></span>
                        </div>
                    <?php endif; ?>

                    <?php if(session('error_delete')): ?>
                        <div class="alert alert-danger">
                          <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
                            <i class="tim-icons icon-simple-remove"></i>
                          </button>
                          <span>
                            <b> <?php echo e(session('error_delete')); ?></span>
                        </div>
                    <?php endif; ?>

                    <div class="">

                        <?php if(count($disertantes ) > 0): ?>
                        <table class="table tablesorter table-hover table-click" id="">
                            <thead class=" text-primary">
                                <th scope="col"></th>
                                <th scope="col"><?php echo e(__('Name')); ?></th>
                                <th scope="col"><?php echo e(__('Email')); ?></th>
                                <th scope="col"><?php echo e(__('Creation Date')); ?></th>
                                <th scope="col"></th>
                                
                            </thead>
                            <tbody>
                                    <?php
                                        $i = 0;
                                    ?>

                                    <?php $__currentLoopData = $disertantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disertante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php
                                            $i++;
                                        ?>
                                        <tr >
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e(Str::title($disertante->nombre)); ?> <?php echo e(Str::title($disertante->apellido)); ?></td>
                                            <td>
                                                <a href="mailto:<?php echo e($disertante->email); ?>"><?php echo e($disertante->email); ?></a>
                                            </td>
                                            <td><?php echo e(($disertante->created_at)); ?></td>
                                            <td class="text-right">
                                                <div class="dropdown">
                                                    <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="fas fa-ellipsis-v"></i>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                                            <form action="<?php echo e(route('disertantes.destroy', $disertante->disertante_id)); ?>" method="get">
                                                                <?php echo csrf_field(); ?>
                                                                

                
                                                                <a class="dropdown-item" href="<?php echo e(route('disertantes.edit', $disertante->id)); ?>"><?php echo e(__('Editar')); ?></a>
                                                                <button type="button" class="dropdown-item" onclick="confirm('<?php echo e(__("¿Está seguro de eliminar este disertante?")); ?>') ? this.parentElement.submit() : ''">
                                                                            <?php echo e(__('Eliminar')); ?>

                                                                </button>
                                                            </form>
                                                    </div>
                                                </div>
                                            </td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                            <p class="text-center">Aún no hay Disertantes</p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-footer py-4">
                    <nav class="d-flex justify-content-end" aria-label="...">
                       
                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['pageSlug' => 'disertantes'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paline/gits/congreso/resources/views/disertantes/index.blade.php ENDPATH**/ ?>