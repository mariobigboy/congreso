<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card ">
                <div class="card-header">
                    <div class="row">
                        <div class="col-8">
                            <h4 class="card-title"><?php echo e(__('Noticias')); ?></h4>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('noticias.create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Nueva Noticia')); ?></a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php if(count($noticias ) > 0): ?>
                    <table class="table tablesorter table-hover table-click" id="">
                        <thead class=" text-primary">
                            <th scope="col"></th>
                            <th scope="col"><?php echo e(__('Imágen')); ?></th>
                            <th scope="col"><?php echo e(__('Título')); ?></th>
                            <th scope="col"><?php echo e(__('By')); ?></th>
                            <th scope="col"><?php echo e(__('Creation Date')); ?></th>
                            <th scope="col"></th>
                            
                        </thead>
                        <tbody>
                                <?php
                                    $i = 0;
                                ?>

                                <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <?php
                                        $i++;
                                    ?>
                                    <tr >
                                        <td><?php echo e($i); ?></td>
                                        <td style="width:20%;"><img style="width:100%;" src="<?php echo e(asset('')); ?>images/noticias/thumbs/<?php echo e($noticia->foto_url); ?>" alt=""></td>
                                        <td><?php echo e(Str::limit(strip_tags($noticia->cuerpo),30,'...')); ?></td>
                                        <td><?php echo e($noticia->user->persona->nombre); ?> <?php echo e($noticia->user->persona->apellido); ?></td>
                                        <td><?php echo e(($noticia->created_at->format('d/m/Y H:i'))); ?></td>
                                        <td class="text-right">
                                            <div class="dropdown">
                                                <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="fas fa-ellipsis-v"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                                        <form action="noticias/delete/<?php echo e($noticia->id); ?>" method="get">
                                                            <?php echo csrf_field(); ?>
                                                            
                                                            <a class="dropdown-item" href="noticias/edit/<?php echo e($noticia->id); ?>"><?php echo e(__('Editar')); ?></a>
                                                            <button type="button" class="dropdown-item" onclick="confirm('<?php echo e(__("¿Está seguro de eliminar este disertante?")); ?>') ? this.parentElement.submit() : ''">
                                                                        <?php echo e(__('Eliminar')); ?>

                                                            </button>
                                                        </form>
                                                </div>
                                            </div>
                                        </td>
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                        <p class="text-center">Aún no hay Disertantes</p>
                    <?php endif; ?>
                </div>
                <div class="card-footer py-4">
                    <nav class="d-flex justify-content-end" aria-label="...">
                       
                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['pageSlug' => 'noticias'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paline/gits/congreso/resources/views/noticias/index.blade.php ENDPATH**/ ?>