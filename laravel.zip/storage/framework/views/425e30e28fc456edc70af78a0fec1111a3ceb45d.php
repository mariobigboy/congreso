<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card ">
                <div class="card-header">
                    <div class="row">
                        <div class="col-8">
                            <h4 class="card-title"><strong><?php echo e(__('Asistentes Registrados')); ?></strong></h4>
                        </div>
                        <div class="col-4 text-right">
                            <!--<a href="<?php echo e(route('asistentes.create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Nuevo Asistente')); ?></a>-->
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="">
                        <?php if(count($asistentes ) > 0): ?>
                        <table class="table tablesorter " id="">
                            <thead class=" text-primary">
                                <th scope="col"> </th>
                                <th scope="col"><?php echo e(__('Nombre y Apellido')); ?></th>
                                <th scope="col"><?php echo e(__('Email')); ?></th>
                                <th scope="col"><?php echo e(__('Dni')); ?></th>
                                <th scope="col"><?php echo e(__('telefono')); ?></th>
                                <th scope="col"><?php echo e(__('Registrado')); ?></th>
                                <th scope="col"><?php echo e(__('Matricula')); ?></th>
                                
                            </thead>
                            <tbody>
                                    <?php
                                        $i = 0;
                                    ?>

                                    <?php $__currentLoopData = $asistentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asistente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $i++;
                                        ?>
                                        <tr>
                                            <td><?php echo e($i); ?></td>
                                            <td><?php echo e($asistente->nombre); ?> <?php echo e($asistente->apellido); ?></td>
                                            <td>
                                                <a href="mailto:<?php echo e($asistente->email); ?>"><?php echo e($asistente->email); ?></a>
                                            </td>
                                            <td><?php echo e($asistente->dni); ?></td>
                                            <td><?php echo e($asistente->telefono); ?></td>
                                            <td><?php echo e(($asistente->created_at)); ?></td>
                                            <td><?php echo e($asistente->matricula_id == NULL? 'No pagada' : 'Pagada'); ?></td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                            <p class="text-center">Aún no hay asistentes</p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-footer py-4">
                    <nav class="d-flex justify-content-end" aria-label="...">
                       
                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['pageSlug' => 'asistentes'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paline/gits/congreso/resources/views/asistentes/index.blade.php ENDPATH**/ ?>