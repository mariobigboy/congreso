<div class="sidebar" data="green">
    <div class="sidebar-wrapper">
        <div class="logo">
            <a href="#" class="simple-text logo-mini"><?php echo e(__('AOA')); ?></a>
            <a href="#" class="simple-text logo-normal"><?php echo e(__('ADMINISTRACIÓN')); ?></a>
        </div>
        <ul class="nav">

            <?php if(Auth::user()->hasRole('superadmin')): ?>
                <!-- aquí los items para Super administrador: -->
                <li <?php if(isset($pageSlug) && $pageSlug == 'dashboard'): ?> class="active " <?php endif; ?>>
                    <a href="<?php echo e(route('home')); ?>">
                        <i class="tim-icons icon-chart-pie-36"></i>
                        <p><?php echo e(__('Dashboard')); ?></p>
                    </a>
                </li>

                <li <?php if(isset($pageSlug) && $pageSlug == 'asistentes'): ?> class="active " <?php endif; ?>>
                    <a href="<?php echo e(route('asistentes.index')); ?>">
                        <i class="tim-icons icon-single-02"></i>
                        <p><?php echo e(__('Asistentes')); ?></p>
                    </a>
                </li>

                <li <?php if(isset($pageSlug) && $pageSlug == 'disertantes'): ?> class="active " <?php endif; ?>>
                    <a href="<?php echo e(route('disertantes.index')); ?>">
                        <i class="tim-icons icon-badge"></i>
                        <p><?php echo e(__('Disertantes')); ?></p>
                    </a>
                </li>

                <li <?php if(isset($pageSlug) && $pageSlug == 'programas'): ?> class="active " <?php endif; ?>>
                    <a href="<?php echo e(route('programas.index')); ?>">
                        <i class="tim-icons icon-notes"></i>
                        <p><?php echo e(__('Programas')); ?></p>
                    </a>
                </li>

                <li <?php if(isset($pageSlug) && $pageSlug == 'noticias'): ?> class="active " <?php endif; ?>>
                    <a href="<?php echo e(route('noticias.index')); ?>">
                        <i class="tim-icons icon-paper"></i>
                        <p><?php echo e(__('Noticias')); ?></p>
                    </a>
                </li>

                <li <?php if(isset($pageSlug) && $pageSlug == 'cursos'): ?> class="active " <?php endif; ?>>
                    <a href="<?php echo e(route('cursos.index')); ?>">
                        <i class="tim-icons icon-trophy"></i>
                        <p><?php echo e(__('Cursos')); ?></p>
                    </a>
                </li>

                <li <?php if(isset($pageSlug) && $pageSlug == 'galerias'): ?> class="active " <?php endif; ?>>
                    <a href="<?php echo e(route('pages.galerias')); ?>">
                        <i class="tim-icons icon-image-02"></i>
                        <p><?php echo e(__('Galerías')); ?></p>
                    </a>
                </li>

                
                <li>
                    <a data-toggle="collapse" href="#laravel-examples" aria-expanded="false">
                        <i class="fab fa-laravel" ></i>
                        <span class="nav-link-text" ><?php echo e(__('Laravel Examples')); ?></span>
                        <b class="caret mt-1"></b>
                    </a>

                    <div class="collapse show" id="laravel-examples">
                        <ul class="nav pl-4">
                            <li <?php if(isset($pageSlug) && $pageSlug == 'profile'): ?> class="active " <?php endif; ?>>
                                <a href="<?php echo e(route('profile.edit')); ?>">
                                    <i class="tim-icons icon-single-02"></i>
                                    <p><?php echo e(__('User Profile')); ?></p>
                                </a>
                            </li>
                            
                            <li <?php if(isset($pageSlug) && $pageSlug == 'users'): ?> class="active " <?php endif; ?>>
                                <a href="<?php echo e(route('user.index')); ?>">
                                    <i class="tim-icons icon-bullet-list-67"></i>
                                    <p><?php echo e(__('User Management')); ?></p>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
                <li <?php if(isset($pageSlug) && $pageSlug == 'icons'): ?> class="active " <?php endif; ?>>
                    <a href="<?php echo e(route('pages.icons')); ?>">
                        <i class="tim-icons icon-atom"></i>
                        <p><?php echo e(__('Icons')); ?></p>
                    </a>
                </li>
                <li <?php if(isset($pageSlug) && $pageSlug == 'maps'): ?> class="active " <?php endif; ?>>
                    <a href="<?php echo e(route('pages.maps')); ?>">
                        <i class="tim-icons icon-pin"></i>
                        <p><?php echo e(__('Maps')); ?></p>
                    </a>
                </li>
                <li <?php if(isset($pageSlug) && $pageSlug == 'notifications'): ?> class="active " <?php endif; ?>>
                    <a href="<?php echo e(route('pages.notifications')); ?>">
                        <i class="tim-icons icon-bell-55"></i>
                        <p><?php echo e(__('Notifications')); ?></p>
                    </a>
                </li>
                <li <?php if(isset($pageSlug) && $pageSlug == 'tables'): ?> class="active " <?php endif; ?>>
                    <a href="<?php echo e(route('pages.tables')); ?>">
                        <i class="tim-icons icon-puzzle-10"></i>
                        <p><?php echo e(__('Table List')); ?></p>
                    </a>
                </li>
                <li <?php if(isset($pageSlug) && $pageSlug == 'typography'): ?> class="active " <?php endif; ?>>
                    <a href="<?php echo e(route('pages.typography')); ?>">
                        <i class="tim-icons icon-align-center"></i>
                        <p><?php echo e(__('Typography')); ?></p>
                    </a>
                </li>
                <!--<li <?php if(isset($pageSlug) && $pageSlug == 'rtl'): ?> class="active " <?php endif; ?>>
                    <a href="<?php echo e(route('pages.rtl')); ?>">
                        <i class="tim-icons icon-world"></i>
                        <p><?php echo e(__('RTL Support')); ?></p>
                    </a>
                </li>-->
                <!--<li class=" <?php echo e(isset($pageSlug) && $pageSlug == 'upgrade' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('pages.upgrade')); ?>">
                        <i class="tim-icons icon-spaceship"></i>
                        <p><?php echo e(__('Upgrade to PRO')); ?></p>
                    </a>
                </li>-->
            <?php endif; ?>

            <?php if(Auth::user()->hasRole('admin')): ?>
                <!-- aquí los items para Administrador: -->
            <?php endif; ?>

            <?php if(Auth::user()->hasRole('user')): ?>
                <!-- aquí los items para usuario: -->
            <?php endif; ?>


        </ul>
    </div>
</div>
<?php /**PATH /home/paline/gits/congreso/resources/views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>