<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
</head>
<body>
	<div class="container text-center mb-5">
		<img src="img/core-img/logoSolo.svg" alt="" style="width:40%;margin-bottom: 50px;">
		<h2>Inscripción AOA - 2.020</h2>
		<p>Inscripción de asistentes.</p>
	</div>
	<div class="container " style="margin-bottom: 100px;">
		<?php if(session('success_register')): ?>
			<div class="alert alert-success" role="alert">
			  Usuario registrado correctamente. Ingrese a su correo para confirmar su email.
			</div>
		<?php endif; ?>


		

		<form id="formFormulario" action="<?php echo e(route('inscripcion.store')); ?>" method="post">
			<?php echo csrf_field(); ?>

			<div class="form-row">
			  	<div class="form-group col-md-6">
			      <label for="inpNombres" class="col-md-5">Nombres</label>
			      <div class="col-md-12">
			      	<input type="text" class="form-control <?php echo e(($errors->has('nombres')? ' border-danger' : '')); ?>" id="inpNombres" name="nombres" placeholder="Nombres">
			      	<?php if($errors->has('nombres')): ?>
			      		<small class="text-danger"><?php echo e($errors->first('nombres')); ?></small>
			      	<?php endif; ?>
			      </div>
			    </div>

			    <div class="form-group col-md-6">
			      <label for="inpApellidos" class="col-md-5">Apellidos</label>
			      <div class="col-md-12">
			      	<input type="text" class="form-control <?php echo e(($errors->has('apellidos')? ' border-danger' : '')); ?>" id="inpApellidos" name="apellidos" placeholder="Apellidos">
			      	<?php if($errors->has('apellidos')): ?>
			      		<small class="text-danger"><?php echo e($errors->first('apellidos')); ?></small>
			      	<?php endif; ?>
			      </div>
			    </div>

			    <div class="form-group col-md-6">
			      <label for="inpDni" class="col-md-5">DNI</label>
			      <div class="col-md-12">
			      	<input type="text" class="form-control <?php echo e(($errors->has('dni')? ' border-danger' : '')); ?>" id="inpDni" name="dni" placeholder="00000000">
			      	<?php if($errors->has('dni')): ?>
			      		<small class="text-danger"><?php echo e($errors->first('dni')); ?></small>
			      	<?php endif; ?>
			      </div>
			    </div>

			    <div class="form-group col-md-6">
			      <label for="inpEmail" class="col-md-5">Email</label>
			      <div class="col-md-12">
			      	<input type="email" class="form-control <?php echo e(($errors->has('email')? ' border-danger' : '')); ?>" id="inpEmail" name="email" placeholder="email@ejemplo.com">
			      	<?php if($errors->has('email')): ?>
			      		<small class="text-danger"><?php echo e($errors->first('email')); ?></small>
			      	<?php endif; ?>
			      </div>
			    </div>

			    <div class="form-group col-md-6">
			      <label for="input-telefono" class="col-md-5">Teléfono</label>
			      <div class="col-md-12">
			      	<input type="text" class="form-control" id="input-telefono" name="telefono" placeholder="+54 387 000 0000">
			      </div>
			    </div>

			    <div class="form-group col-md-6">
			      <label for="inpPass" class="col-md-5">Contraseña</label>
			      <div class="col-md-12">
			      	<input type="password" class="form-control <?php echo e(($errors->has('password')? ' border-danger' : '')); ?>" id="inpPass" name="password" placeholder="Contraseña">
			      	<?php if($errors->has('password')): ?>
			      		<small class="text-danger"><?php echo e($errors->first('password')); ?></small>
			      	<?php endif; ?>
			      </div>
			    </div>

			</div>
			<div class="form-group col-md-12 text-left">
				<button type="submit" class="btn btn-primary">Registrar!</button>
			</div>

		  
		  
		 
		</form>
	</div>

	<!-- jQuery 2.2.4 -->
    <script src="js/jquery.min.js"></script>

	</script>
</body>
</html><?php /**PATH /home/paline/gits/congreso/resources/views/inscripcion.blade.php ENDPATH**/ ?>