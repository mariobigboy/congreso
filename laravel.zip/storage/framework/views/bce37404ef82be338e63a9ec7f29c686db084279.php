<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card ">
                <div class="card-header">
                    <div class="row">
                        <div class="col-8">
                            <h4 class="card-title"><?php echo e(__('Cursos')); ?></h4>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('cursos.index')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Ver Cursos')); ?></a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                          <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
                            <i class="tim-icons icon-simple-remove"></i>
                          </button>
                          <span>
                            <b> <?php echo e(session('success')); ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                          <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
                            <i class="tim-icons icon-simple-remove"></i>
                          </button>
                          <span>
                            <b> <?php echo e(session('error')); ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if($disertantes->count()>0): ?>
                        <form action="<?php echo e(route('cursos.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <!-- disertante -->
                            <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                <label class="form-control-label" for="input-nombre"><?php echo e(__('Nombre')); ?></label>
                                <select name="disertante_id" id="idPersona" class="form-control" required>
                                    <option value="">Seleccione Disertante</option>
                                    <?php $__currentLoopData = $disertantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disertante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($disertante->id); ?>"><?php echo e($disertante->persona->nombre); ?> <?php echo e($disertante->persona->apellido); ?></option>
                                        }
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                
                                <?php echo $__env->make('alerts.feedback', ['field' => 'disertante_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <!-- tema -->
                            <div class="form-group<?php echo e($errors->has('tema') ? ' has-danger' : ''); ?>">
                                <label class="form-control-label" for="input-tema"><?php echo e(__('Tema')); ?></label>
                                <input type="text" name="tema" id="input-tema" class="form-control form-control-alternative<?php echo e($errors->has('tema') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Tema')); ?>" value="<?php echo e(old('tema')); ?>" required autofocus>
                                <?php echo $__env->make('alerts.feedback', ['field' => 'tema'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <!-- fecha -->
                            <div class="form-group<?php echo e($errors->has('fecha_curso') ? ' has-danger' : ''); ?>">
                                <label class="form-control-label" for="input-fecha"><?php echo e(__('Fecha')); ?></label>
                                <input type="text" name="fecha_curso" id="input-fecha" class="form-control form-control-alternative<?php echo e($errors->has('fecha_curso') ? ' is-invalid' : ''); ?> datepicker" placeholder="<?php echo e(__('Fecha')); ?>" value="<?php echo e(old('fecha_curso')); ?>" required>
                                <?php echo $__env->make('alerts.feedback', ['field' => 'nombre'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <!-- hora -->
                            <div class="form-group<?php echo e($errors->has('hora_curso') ? ' has-danger' : ''); ?>">
                                <label class="form-control-label" for="input-hora"><?php echo e(__('Hora')); ?></label>
                                <input type="text" name="hora_curso" id="input-hora" class="form-control form-control-alternative<?php echo e($errors->has('hora_curso') ? ' is-invalid' : ''); ?> timepicker" placeholder="<?php echo e(__('Hora')); ?>" value="<?php echo e(old('hora_curso')); ?>" required >
                                <?php echo $__env->make('alerts.feedback', ['field' => 'hora_curso'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <!-- contenido -->
                            <div class="form-group<?php echo e($errors->has('contenido') ? ' has-danger' : ''); ?>">
                                <label class="form-control-label" for="input-contenido"><?php echo e(__('Contenido')); ?></label>
                                <textarea name="contenido" id="input-contenido" class="form-control form-control-alternative<?php echo e($errors->has('contenido') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Contenido')); ?>"  required></textarea>
                                <?php echo $__env->make('alerts.feedback', ['field' => 'contenido'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <!-- lugar -->
                            <div class="form-group<?php echo e($errors->has('lugar') ? ' has-danger' : ''); ?>">
                                <label class="form-control-label" for="input-lugar"><?php echo e(__('Lugar')); ?></label>
                                <input type="text" name="lugar" id="input-lugar" class="form-control form-control-alternative<?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Lugar')); ?>" value="<?php echo e(old('lugar')); ?>" required >
                                <?php echo $__env->make('alerts.feedback', ['field' => 'lugar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>

                            <div class="text-left">
                                <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Guardar')); ?></button>
                            </div>
                        </form>
                    <?php else: ?>
                        <p class="text-center">Debe existir un disertante para asociarlo a un curso, puede crear uno nuevo clickeando <a href="<?php echo e(route('disertantes.create')); ?>"><strong>aquí</strong></a></p>
                    <?php endif; ?>
                </div>
                <div class="card-footer py-4">
                    <nav class="d-flex justify-content-end" aria-label="...">
                       
                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['pageSlug' => 'cursos'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paline/gits/congreso/resources/views/cursos/create.blade.php ENDPATH**/ ?>