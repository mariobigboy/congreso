<?php $__env->startSection('content'); ?>

    
    <div class="row">
        <div class="col-md-12">
            <div class="card ">
                <div class="card-header">
                    <div class="row">
                        <div class="col-8">
                            <h4 class="card-title"><strong><?php echo e(__('Editar Disertante')); ?></strong></h4>
                        </div>
                        <div class="col-4 text-right">
                            <a href="<?php echo e(route('disertantes.index')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Ver Disertantes')); ?></a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('disertantes.update')); ?>" autocomplete="off" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                        <input type="hidden" name="id" value="<?php echo e($persona->get('id')); ?>">
                        <h6 class="heading-small text-muted mb-4"><?php echo e(__('Información del Disertante')); ?></h6>
                        <div class="pl-lg-4">

                            <!-- Prefijo -->
                            <div class="form-group<?php echo e($errors->has('prefijo') ? ' has-danger' : ''); ?>">
                                <label class="form-control-label" for="input-prefijo"><?php echo e(__('Prefijo')); ?></label>
                                <input type="text" name="prefijo" id="input-prefijo" class="form-control form-control-alternative<?php echo e($errors->has('prefijo') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Dr. Doctor ')); ?>" value="<?php echo e($persona->get('prefijo')); ?>" autofocus>
                                <?php echo $__env->make('alerts.feedback', ['field' => 'prefijo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <!-- nombre -->
                            <div class="form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                                <label class="form-control-label" for="input-nombre"><?php echo e(__('Nombre')); ?></label>
                                <input type="text" name="nombre" id="input-nombre" class="form-control form-control-alternative<?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Nombre')); ?>" value="<?php echo e($persona->get('nombre')); ?>" required autofocus>
                                <?php echo $__env->make('alerts.feedback', ['field' => 'nombre'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <!-- apellido -->
                            <div class="form-group<?php echo e($errors->has('apellido') ? ' has-danger' : ''); ?>">
                                <label class="form-control-label" for="input-apellido"><?php echo e(__('Apellido')); ?></label>
                                <input type="text" name="apellido" id="input-apellido" class="form-control form-control-alternative<?php echo e($errors->has('apellido') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Apellidos')); ?>" value="<?php echo e($persona->get('apellido')); ?>" required autofocus>
                                <?php echo $__env->make('alerts.feedback', ['field' => 'apellido'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <!-- dni -->
                            <div class="form-group<?php echo e($errors->has('dni') ? ' has-danger' : ''); ?>">
                                <label class="form-control-label" for="input-dni"><?php echo e(__('DNI')); ?></label>
                                <input type="text" name="dni" id="input-dni" class="form-control form-control-alternative<?php echo e($errors->has('dni') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Documento')); ?>" value="<?php echo e($persona->get('dni')); ?>" disabled autofocus>
                                <?php echo $__env->make('alerts.feedback', ['field' => 'dni'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>

                            <!-- email -->
                            <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                                <label class="form-control-label" for="input-email"><?php echo e(__('Email')); ?></label>
                                <input type="email" name="email" id="input-email" class="form-control form-control-alternative<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Email')); ?>" value="<?php echo e($persona->get('email')); ?>" disabled>
                                <?php echo $__env->make('alerts.feedback', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <!-- telefono -->
                            <div class="form-group<?php echo e($errors->has('telefono') ? ' has-danger' : ''); ?>">
                                <label class="form-control-label" for="input-telefono"><?php echo e(__('Teléfono')); ?></label>
                                <input type="text" name="telefono" id="input-telefono" class="form-control form-control-alternative<?php echo e($errors->has('telefono') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('Teléfono')); ?>" value="<?php echo e($persona->get('telefono')); ?>" required autofocus>
                                <?php echo $__env->make('alerts.feedback', ['field' => 'telefono'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <!-- Pais -->
                            <div class="form-group<?php echo e($errors->has('pais') ? ' has-danger' : ''); ?>">
                                <label class="form-control-label" for="input-pais"><?php echo e(__('País')); ?></label>
                                <input type="text" name="pais" id="input-pais" class="form-control form-control-alternative<?php echo e($errors->has('pais') ? ' is-invalid' : ''); ?>" placeholder="<?php echo e(__('País')); ?>" value="<?php echo e($persona->get('pais')); ?>" required>
                                <?php echo $__env->make('alerts.feedback', ['field' => 'pais'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <!-- fecha_congreso -->
                            <!--<div class="form-group">
                                <label class="form-control-label " for="input-fecha"><?php echo e(__('Fecha')); ?></label>
                                <input type="text" name="fecha_congreso" id="input-fecha" class="form-control form-control-alternative datepicker" placeholder="<?php echo e(__('31/12/2020')); ?>" value="<?php echo e($persona->get('fecha_congreso')); ?>" required>
                            </div>-->
                            <!-- horario_congreso -->
                            <!--<div class="form-group">
                                <label class="form-control-label " for="input-hora"><?php echo e(__('Horario')); ?></label>
                                <input type="text" name="hora_congreso" id="input-hora" class="form-control form-control-alternative timepicker" placeholder="<?php echo e(__('00:00')); ?>" value="<?php echo e($persona->get('hora_congreso')); ?>" required>
                            </div>-->

                            <!-- foto -->
                            <div class="form-group">
                                <label for="" class="form-control-label"><?php echo e(__('Foto')); ?></label>
                                <div class="input-group mb-3">
                                  <div class="custom-file">
                                    <input type="file" class="custom-file-input form-control" id="input-foto_url" aria-describedby="inputGroupFileAddon01" name="foto_url" >
                                    <label class="custom-file-label" for="input-foto_url">Elegir Foto</label>
                                  </div>
                                </div>
                            </div>

                            <div class="col-lg-12 text-center">
                                <img style="" id="preview_foto" width="50%" src="<?php echo e(asset('')); ?>images/avatar/<?php echo e($persona->get('foto_url')); ?>" alt="">
                            </div>

                            <div class="text-left">
                                <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Guardar Cambios')); ?></button>
                                <a href="<?php echo e(route('disertantes.destroy', $persona->get('id'))); ?>" type="button" class="btn btn-danger mt-4"><?php echo e(__('Eliminar')); ?></a>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="card-footer py-4">
                    <nav class="d-flex justify-content-end" aria-label="...">
                       
                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['pageSlug' => 'disertantes'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paline/gits/congreso/resources/views/disertantes/edit.blade.php ENDPATH**/ ?>