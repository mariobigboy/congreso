# pickadate.js
Shim repository for https://github.com/amsul/pickadate.js

# Package Managers

Composer: rohnstock/pickadate